#!/usr/bin/env python3

from mappers import Database


class User:

    def __init__(self,username,password):
        self.username = username
        self.password = password

    def login(self):
        # SELECT password FROM users WHERE username='{submitted_username}';
        with Database() as d:
            d.cursor.execute(
                f'''SELECT password
                    FROM users
                    WHERE username='{self.username}';''')
            password = d.cursor.fetchone()[0]
            if password:
                if self.password == password:
                    return True
            return False


if __name__ == '__main__':
    user = User('cookiemonster','opensesame')
    print(user.login())
